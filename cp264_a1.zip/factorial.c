/*
 -------------------------------------
 File:    factorial.c
 Project: cp264_a1
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-01-18
 -------------------------------------
 */

#include <stdio.h>

int main(int argc, char *args[]) {
	int n = 0, x, f = 1, is_overflow = 0;
	if (argc > 1) {
		sscanf(args[1], "%d", &n); // this gets integer value from command line argument argv[1].

		if (n >= 1) {

			// your code to compute factorial n!

			for (int i = 1; i <= n; i++) {
				f = f * i;
			}

			if (n < 13) {
				printf("%d!:%d\n", n, f);
			} else {
				printf("%s!:overflow\n", args[1]);
			}

		} else {
			printf("%s:invalid\n", args[1]);
		}
	} else {
		printf("argument input:missing\n");
	}
	return 0;
}
