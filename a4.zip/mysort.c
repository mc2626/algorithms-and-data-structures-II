/*
 -------------------------------------
 File:    mysort.c
 Project: cvet1400_a4
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-02-09
 -------------------------------------
 */

#include "mysort.h"

BOOLEAN is_sorted(float *a, int left, int right) {
	BOOLEAN result = true;
	int i = left;
	while (result && i < right) {
		if (*(a + i) > *(a + i + 1)) {
			result = false;
		}
		i++;
	}
	return result;
}

void select_sort(float *a, int left, int right) {

	int k;
	float temp;
	int n = right - left + 1;
	if (left < right) {
		for (int i = 0; i < n; i++) {
			k = i;
			for (int j = i + 1; j < n; j++) {
				if (*(a + j) < *(a + k)) {
					k = j;
				}
			}
			if (i != k) {
				temp = *(a + k);
				*(a + k) = *(a + i);
				*(a + i) = temp;
			}
		}
	}

}

void quick_sort(float *a, int left, int right) {

	float key;
	int i, j, k;
	if (left < right) {
		k = left;
		i = left;
		j = right;
		while (i < j) {
			while (*(a + i) <= *(a + k) && i <= right)
				i++;
			while (*(a + j) > *(a + k) && j >= left)
				j--;
			if (i < j) {
				key = *(a + i);
				*(a + i) = *(a + j);
				*(a + j) = key;
			}
		}
		key = *(a + j);
		*(a + j) = *(a + k);
		*(a + k) = key;
		quick_sort(a, left, j - 1);
		quick_sort(a, j + 1, right);
	}
}
