/*
 -------------------------------------
 File:    mysort.h
 Project: cvet1400_a4
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-02-09
 -------------------------------------
 */
#ifndef MYSORT_H
#define MYSORT_H

typedef enum {
	false, true
} BOOLEAN;
BOOLEAN is_sorted(float *a, int left, int right);
void select_sort(float *a, int left, int right);
void quick_sort(float *a, int left, int right);

#endif
