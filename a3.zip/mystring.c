/*
 -------------------------------------
 File:    mystring.c
 Project: cp264_a3
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-01-24
 -------------------------------------
 */

#include "mystring.h"
#define NULL 0

// computes and returns the number of characters of string passed by s (including space).
int str_length(char *s) {

	int count = 0;
	if (s == NULL) {
		count = -1;
	} else {
		char *p = s;
		while (*p) {
			count++;
			p++;
		}
	}
	return count;
}

// computes and returns the number of words of string passed by s.
int word_count(char *s) {

	int count = 0;
	char *p;
	if (str_length(s) == NULL) {
		count = -1;
	} else {
		p = s;
		while (*p) {
			if (*p != 32 && *(p - 1) == 32) {
				count++;
			}
			p++;
		}
	}

	return count;
}

// changes upper case to lower case of string passed by s.
void lower_case(char *s) {

	if (s) {
		char *p = s; // points to the first byte in s
		while (*p) {
			if (*p >= 65 && *p <= 90) {
				*p += 32;
			}
			p++;
		};
	}
	return;
}

// removes unnecessary space characters in string passed by s.
void str_trim(char *s) {
	char *p = s, *dp = s;
	while (*p) {
		if (*p != 32 || (p > s && *(p - 1) != 32)) {
			*dp = *p;
			dp++;
		}
		p++;
	}

	if (*(dp - 1) == 32) {
		*(dp - 1) = '\0';
	} else {
		*dp = '\0';
	}

	return;
}
