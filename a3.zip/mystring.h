/*
 -------------------------------------
 File:    mystring.h
 Project: cp264_a3
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-01-24
 -------------------------------------
 */
#ifndef MYSTRING_H
#define MYSTRING_H

int str_length(char*);
int word_count(char*);
void lower_case(char*);
void str_trim(char*);

#endif
