/*
 -------------------------------------
 File:    expression_symbol.h
 Project: cp264_a9
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-03-20
 -------------------------------------
 */

#ifndef EXPRESSION_SYMBOL_H
#define EXPRESSION_SYMBOL_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"
#include "stack.h"
#include "hash.h"

/* Convert symbolic infix expression to postfix expression, output in queue format */
QUEUE infix_to_postfix_symbol(char *infixstr, HASHTABLE *ht);

/* evaluate symbolic infix expression */
int evaluate_infix_symbol(char *infixstr, HASHTABLE *ht);

int evaluate_postfix(QUEUE queue);

#endif
