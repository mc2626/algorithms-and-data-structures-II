/*
 -------------------------------------
 File:    hash.c
 Project: cp264_a9
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-03-20
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

extern int htsize;

int hash(char *name) {
	unsigned int value = 0, i;
	char *p = name;
	while (*p) {
		value = 31 * value + *p;
		p++;
	}
	return value % htsize;
}

HASHNODE* new_hashnode(char *name, int value) {
	HASHNODE *hn = (HASHNODE*) malloc(sizeof(HASHNODE));
	strcpy(hn->name, name);
	hn->value = value;
	hn->next = NULL;

	return hn;
}

HASHTABLE* new_hashtable(int size) {
	HASHTABLE *ht = (HASHTABLE*) malloc(sizeof(HASHTABLE));
	ht->hna = (HASHNODE**) malloc(sizeof(HASHNODE**) * size);
	int i;
	for (i = 0; i < size; i++)
		*(ht->hna + i) = NULL; // initialize to NULL
	ht->size = size;
	ht->count = 0;
	return ht;
}

HASHNODE* search(HASHTABLE *ht, char *name) {
	int i = hash(name); // compute the hash index of name
	HASHNODE *p = ht->hna[i]; // get the linked list of the hash value

	if (p != NULL) {
		// search the linked list, if name is matched, return the node
		int cond = 1;
		while (p && !cond) {
			if (strcmp(p->name, name) == 0) {
				cond = 0;
			}
			p = p->next;
		}
	}
	return p;

}

int insert(HASHTABLE *ht, HASHNODE *np) {

	int index = hash(np->name);
	HASHNODE *pointer = *(ht->hna + index);
	int condition = 0, flag = 1;
	// not empty linked list
	if (!pointer) {
		*(ht->hna + index) = np;
		ht->count++;
	}
	// empty linked list
	else {
		do {
			if (strcmp(pointer->name, np->name) == 0) {
				condition = 1;
				pointer->value = np->value;
			} else {
				if (pointer->next != NULL) {
					pointer = pointer->next;
				} else {
					flag = 0;
				}
			}
		} while (!condition && pointer && flag);
		if (!condition) {
			pointer->next = np;
			ht->count++;
		}
	}

	return !condition;

}

int delete(HASHTABLE *ht, char *name) {

	int index = hash(name), remove = 0;
	HASHNODE *prevNode = NULL;
	HASHNODE *currNode = *(ht->hna + index);

	while (currNode != NULL) {
		if (strcmp(currNode->name, name) == 0) {
			if (prevNode == NULL) {
				*(ht->hna + index) = currNode->next;
			} else {
				prevNode->next = currNode->next;
			}
			free(currNode);
			ht->count -= 1;
			remove = 1;
		}
		prevNode = currNode;
		currNode = currNode->next;
	}
	return remove;
}

void clean_hash(HASHTABLE **htp) {
	if (*htp == NULL)
		return;
	HASHTABLE *ht = *htp;
	HASHNODE *sp = ht->hna[0], *p, *temp;
	int i;
	for (i = 0; i < ht->size; i++) {
		p = ht->hna[i];
		while (p) {
			temp = p;
			p = p->next;
			free(temp);
		}
		ht->hna[i] = NULL;
	}
	free(ht->hna);
	ht->hna = NULL;
	*htp = NULL;
}

