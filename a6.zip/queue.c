/*
 -------------------------------------
 File:    queue.c
 Project: cp264_a6
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-02-28
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"

/*
 * enqueue a NODE *np and maintain the length property of the Queue.
 */
void enqueue(QUEUE *qp, NODE *np) {

	// queue is empty
	if (qp->front == NULL) {
		qp->front = np;
		qp->rear = np;
	} else {
		qp->rear->next = np;
		qp->rear = np;
		qp->rear->next = NULL;

	}
	qp->length++;

}

/*
 * dequeue and return the pointer of the removed NOPE, maintain length property.
 * do not free the removed node in the function.
 */
NODE* dequeue(QUEUE *qp) {

	// your implementation
	NODE *node = qp->front;
	if (node != NULL) {
		// one element in the queue
		if (qp->length == 1) {
			qp->front = NULL;
			qp->rear = NULL;
		} else {
			qp->front = qp->front->next;
		}
		qp->length--;
	}

	return node;

}

/*
 * delete and free all nodes of the queue, and reset the front, rear, and length.
 */
void clean_queue(QUEUE *qp) {
// your implementation
// call clean() function in common.h
// set qp's front, rare to NULL and length to 0

	NODE *temp, *p = qp->front;

	while (p != NULL) {
		temp = p;
		p = p->next;
		free(temp);
	}
	qp->front = NULL;
	qp->rear = NULL;
	qp->length = 0;
}

