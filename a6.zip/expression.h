/*
 -------------------------------------
 File:    expression.h
 Project: cp264_a6
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-02-28
 -------------------------------------
 */
#ifndef EXPRESSION_H
#define EXPRESSION_H

#include "common.h"
#include "queue.h"

QUEUE infix_to_postfix(char *infixstr);
int evaluate_postfix(QUEUE queue);
int evaluate_infix(char *infixstr);

#endif
