/*
 -------------------------------------
 File:    stack.c
 Project: cp264_a6
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-02-28
 -------------------------------------
 */

#include <stdio.h>
#include "stack.h"

void push(STACK *sp, NODE *np) {
	// if stack is empty
	if (sp->top == NULL) {
		sp->top = np;
	} else {
		np->next = sp->top;
		sp->top = np;
	}
	sp->height++;
}

NODE* pop(STACK *sp) {
// your implementation
	NODE *node = sp->top;
	if (node != NULL) {
		if (sp->height == 1) {
			sp->top = NULL;
		} else {
			sp->top = sp->top->next;
		}
		sp->height--;
	}
	return node;
}

void clean_stack(STACK *sp) {
// your implementation,
	NODE *temp, *p = sp->top;

	while (p != NULL) {
		temp = p;
		p = p->next;
		free(temp);
	}
	sp->top = NULL;
	sp->height = 0;
}
