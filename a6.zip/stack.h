/*
 -------------------------------------
 File:    stack.h
 Project: cp264_a6
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-02-28
 -------------------------------------
 */
#ifndef STACK_H
#define STACK_H

#include "common.h"

typedef struct stack {
	int height;
	NODE *top;
} STACK;

void push(STACK *sp, NODE *np);
NODE* pop(STACK *sp);
void clean_stack(STACK *sp);

#endif
