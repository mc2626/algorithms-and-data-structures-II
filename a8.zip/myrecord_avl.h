/*
 -------------------------------------
 File:    myrecord_avl.h
 Project: cp264_a8
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-03-13
 -------------------------------------
 */
#ifndef MYRECORD_AVL_H
#define MYRECORD_AVL_H
#include "avl.h"

typedef struct {
	int count;
	float mean;
	float stddev;
	float median;
} STATS;

typedef struct {
	TNODE *root;
	STATS stats;
} AVL;

void merge_tree(TNODE **rootp1, TNODE **rootp2);
void merge_data(AVL *t1, AVL *t2);
void clear_avl(AVL *avl);

#endif
