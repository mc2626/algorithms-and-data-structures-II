/*
 -------------------------------------
 File:    myrecord_avl.c
 Project: cp264_a8
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-03-13
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "queue_stack.h"
#include "avl.h"
#include "myrecord_avl.h"

void merge_tree(TNODE **rootp1, TNODE **rootp2) {
	// use recursive or iterative algorithm to traverse tree rootp2,
	// get record data of each node and insert into rootp1

	QUEUE queue = { 0 };
	TNODE *np;
	enqueue(&queue, *rootp2);
	while (queue.front != NULL) {
		np = dequeue(&queue);
		if (np->left)
			enqueue(&queue, np->left);
		if (np->right)
			enqueue(&queue, np->right);

		RECORD r = np->data;
		insert_avl(rootp1, r.name, r.score);
	}
}

void merge_data(AVL *t1, AVL *t2) {
	merge_tree(&t1->root, &t2->root);

	int count1 = t1->stats.count;
	float mean1 = t1->stats.mean;
	float stddev1 = t1->stats.stddev;
	int count2 = t2->stats.count;
	float mean2 = t2->stats.mean;
	float stddev2 = t2->stats.stddev;

	// compute the aggregated count, mean, and stddev
	//using formula in the previous slide

	int count = count1 + count2;
	t1->stats.count = count;

	float mean = (mean1 * (float) count1 + mean2 * (float) count2)
			/ (float) count;
	t1->stats.mean = mean;

	float stddev = sqrtf(
			(1 / (float) count)
					* (stddev1 * stddev1 * (float) count1
							+ mean1 * mean1 * (float) count1
							+ stddev2 * stddev2 * (float) count2
							+ mean2 * mean2 * (float) count2) - (mean * mean));
	t1->stats.stddev = stddev;

}

void clear_avl(AVL *avl) {
	TNODE *root = avl->root;
	clear_tree(&root);
	avl->root = NULL;
	avl->stats.count = 0;
	avl->stats.mean = 0;
	avl->stats.stddev = 0;
	avl->stats.median = 0;
}
