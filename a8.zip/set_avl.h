/*
 -------------------------------------
 File:    set_avl.h
 Project: cp264_a8
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-03-13
 -------------------------------------
 */
#ifndef SET_AVL_H
#define SET_AVL_H

typedef struct {
	TNODE *root;
	int size;
} SET;

int size(SET *s);
int contains_element(SET *s, char *e);
void add_element(SET *s, char *e);
void remove_element(SET *s, char *e);
void clear_set(SET *s);

#endif
