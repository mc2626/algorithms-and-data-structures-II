/*
 -------------------------------------
 File:    set_avl.c
 Project: cp264_a8
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-03-13
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"
#include "set_avl.h"

int size(SET *s) {

	int count = 0;
	if (s->root != NULL)
		count = s->size;
	return count;
}

int contains_element(SET *s, char *e) {

	int contains;
	if (search_avl(s->root, e) == NULL) {
		contains = 0;
	} else {
		contains = 1;
	}
	return contains;

}

void add_element(SET *s, char *e) {

	if (contains_element(s, e) == 0) {
		insert_avl(&s->root, e, s->size);
		s->size++;
	}
}

void remove_element(SET *s, char *e) {

	if (contains_element(s, e) == 1) {
		delete_avl(&s->root, e);
		s->size--;
	}
}

void clear_set(SET *s) {

	clear_tree(&s->root);
	s->root = NULL;
	s->size = 0;
}
