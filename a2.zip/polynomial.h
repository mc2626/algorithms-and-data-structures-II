/*
 -------------------------------------
 File:    polynomial.h
 Project: cp264_a2
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-01-24
 -------------------------------------
 */
#ifndef POLYNOMIAL_H_
#define POLYNOMIAL_H_
#include<stdio.h>
#include<math.h>

#define EPSILON 1e-6

float horner(float p[], int n, float x) {
// your implementation
	float r = 0;
	for (int i = 0; i < n; i++) {
		r = r * x + p[i];
	}
	return r;
}

// compute the derivative of polynomial p[], and output to d[]
void derivative(float p[], int n, float d[]) {
// your implementation
	int i;
	float term;
	for (i = 0; i < n - 1; i++) {
		term = n - (i + 1);
		d[i] = term * p[i];
	}
	return;

}

// Use Newton's method to find and return a root of polynomial of p[]
float newton(float p[], int n, float x0) {
// your implementation
	float x = x0, px, d[n - 1];
	derivative(p, n, d);
	do {
		x0 = x;
		px = horner(p, n, x);
		x -= px / horner(d, n - 1, x);

	} while (fabs(x - x0) > EPSILON || fabs(px) > EPSILON);

	return x;

}

#endif /* POLYNOMIAL_H_ */
