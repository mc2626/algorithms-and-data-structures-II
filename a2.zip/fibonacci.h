/*
 -------------------------------------
 File:    fibonacci.h
 Project: cp264_a1
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-01-24
 -------------------------------------
 */
#ifndef FIBONACCI_H
#define FIBONACCI_H

extern int *la;  // global pointer variable to hold lowest variable address

int recursive_fibonacci(int n) {

	int fib_value;

	if (&n < la)
		la = &n;
	// your implementation of the recursive algorithm
	if (n <= 2) {
		fib_value = 1;
	} else {
		fib_value = recursive_fibonacci(n - 1) + recursive_fibonacci(n - 2);
	}
	return fib_value;

}

int iterative_fibonacci(int n) {

	int fib_value;

	if (&n < la)
		la = &n;

	// your implementation of the iterative algorithm
	if (n <= 2) {
		fib_value = 1;
	} else {
		int f1 = 1, f2 = 1, temp, i;

		for (i = 3; i <= n; i++) {
			temp = f2;
			f2 = f1 + f2;
			f1 = temp;

		}
		fib_value = f2;
	}
	return fib_value;

}
#endif
