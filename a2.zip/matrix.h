/*
 -------------------------------------
 File:    matrix.h
 Project: cp264_a2
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-01-24
 -------------------------------------
 */
#ifndef MATRIX_H
#define MATRIX_H

float vsum(float *v, int n);
float msum(float *m, int n);
void multiply_vector(float *m, float *v1, float *v2, int n);
void transpose_matrix(float *m1, float *m2, int n);
void multiply_matrix(float *m1, float *m2, float *m3, int n);

#endif
