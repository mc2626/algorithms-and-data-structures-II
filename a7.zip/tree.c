/*
 -------------------------------------
 File:    tree.c
 Project: cp264_a7
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-03-09
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "queue_stack.h"
#include "tree.h"

TNODE* new_node(int value) {

	TNODE *p = (TNODE*) malloc(sizeof(TNODE));
	p->data = value;
	p->left = NULL;
	p->right = NULL;
	return p;
}

TPROPS get_props(TNODE *root) {

	TPROPS r = { 0 };
	TPROPS lp, rp;

	if (root) {
		lp = get_props(root->left);
		rp = get_props(root->right);
		r.count = 1 + rp.count + lp.count;
		r.height = ((lp.height > rp.height) ? lp.height : rp.height) + 1;
	}
	return r;
}

void display_preorder(TNODE *root) {

	if (root != NULL) {
		printf("%c ", root->data);
		display_preorder(root->left);
		display_preorder(root->right);

	}
	return;
}

void display_inorder(TNODE *root) {

	if (root != NULL) {
		display_inorder(root->left);
		printf("%c ", root->data);
		display_inorder(root->right);

	}
	return;
}

void display_postorder(TNODE *root) {

	if (root != NULL) {
		display_postorder(root->left);
		display_postorder(root->right);
		printf("%c ", root->data);

	}
	return;
}

/* use auxiliary queue data structure for the algorithm  */
void display_bforder(TNODE *root) {

	QUEUE queue = { 0 };
	if (root != NULL) {
		TNODE *pointer = NULL;
		enqueue(&queue, root);
		while (queue.front) {
			pointer = dequeue(&queue);
			if (pointer != NULL) {
				printf("%c ", pointer->data);
				enqueue(&queue, pointer->left);
				enqueue(&queue, pointer->right);
			}
		}

	}
}

// breadth first search

/* use auxiliary queue data structure for the algorithm  */
TNODE* iterative_bfs(TNODE *root, int val) {

	QUEUE queue = { 0 }; // auxiliary working ds
	TNODE *r = NULL, *p = NULL;
	if (root) {
		enqueue(&queue, root);
		while (queue.front) {
			p = dequeue(&queue);
			if (p->data == val) {
				r = p;
				break;
			}
			if (p->left)
				enqueue(&queue, p->left);
			if (p->right)
				enqueue(&queue, p->right);
		}
		clean_queue(&queue);
	}
	return r;

}

// depth first search

TNODE* iterative_dfs(TNODE *root, int val) {

	STACK stack = { 0 }; // auxiliary working ds
	TNODE *r = NULL, *p = NULL;
	if (root) {
		push(&stack, root);
		while (stack.top) {
			p = (TNODE*) (stack.top)->data;
			if (p->data == val) {
				r = p;
				break;
			}
			pop(&stack);
			if (p->right)
				push(&stack, p->right);
			if (p->left)
				push(&stack, p->left); // left child first search
		}
	}
	clean_stack(&stack);

	return r;
}

void clean_tree(TNODE **rootp) {

	TNODE *p = *rootp;
	if (p != NULL) {
		if (p->left != NULL) {
			clean_tree(&p->left);
		}
		if (p->right != NULL) {
			clean_tree(&p->right);
		}
		free(p);
	}
	*rootp = NULL;
}

