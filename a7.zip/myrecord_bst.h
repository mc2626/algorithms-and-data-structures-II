/*
 -------------------------------------
 File:    myrecord_bst.h
 Project: cp264_a7
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-03-09
 -------------------------------------
 */
#ifndef MYRECORD_BST_H
#define MYRECORD_BST_H

typedef struct {
	TNODE *root;
} BST;

typedef struct {
	int count;
	float mean;
	float stddev;
	float median;
} STATS;

void add_data(BST *bst, STATS *stats, char *name, float score);
void remove_data(BST *bst, STATS *stats, char *name);
#endif
