/*
 -------------------------------------
 File:    bst.c
 Project: cp264_a7
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-03-09
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"

// you can add auxiliary function for the insert and delete operations

TNODE* new_node(char *name, float score) {

	TNODE *p = (TNODE*) malloc(sizeof(TNODE));
	RECORD r = { 0 };
	strcpy(r.name, name);
	r.score = score;
	p->data = r;
	p->left = NULL;
	p->right = NULL;
	return p;
}

void clean_tree(TNODE **rootp) {

	TNODE *p = *rootp;
	if (p != NULL) {
		if (p->left != NULL) {
			clean_tree(&p->left);
		}
		if (p->right != NULL) {
			clean_tree(&p->right);
		}
		free(p);
	}
	*rootp = NULL;
}

TNODE* search(TNODE *root, char *name) {

	TNODE *curr = root;
	int key = 0;
	while (!key && curr) {
		if (strcmp(curr->data.name, name) == 0) {
			key = 1;
		} else if (strcmp(curr->data.name, name) > 0) {
			curr = curr->left;
		} else {
			curr = curr->right;
		}
	}
	return curr;

}

void insert(TNODE **rootp, char *name, float score) {

	TNODE *newnp = new_node(name, score);
	if (*rootp == NULL) {
		*rootp = newnp;
	} else {
		if (strcmp(newnp->data.name, (*rootp)->data.name) != 0) {
			if (strcmp(newnp->data.name, (*rootp)->data.name) < 0) {
				insert(&(*rootp)->left, name, score);
			} else if (strcmp(newnp->data.name, (*rootp)->data.name) > 0) {
				insert(&(*rootp)->right, name, score);
			}
		}
	}
}

/*aux function for delete method */
TNODE* extract_smallest_node(TNODE **rootp) {
	TNODE *p = *rootp, *parent = NULL;
	if (p) {
		while (p->left) {
			parent = p;
			p = p->left;
		}

		if (parent == NULL)
			*rootp = p->right;
		else
			parent->left = p->right;

		p->left = NULL;
		p->right = NULL;
	}

	return p;
}

void delete(TNODE **rootp, char *name) {

	TNODE *current = *rootp, *child;
	TNODE **prev = NULL;
	int flag = 0; // represents is value is found or not
	if (current == NULL)
		return;
	while (current != NULL && !flag) {
		if (strcmp(current->data.name, name) == 0) {
			if (current->left == NULL && current->right == NULL) {
				free(current);
				*prev = NULL;
			} else if (current->left != NULL && current->right == NULL) {
				child = current->left;
				*prev = child;
				free(current);
			} else if (current->left == NULL && current->right != NULL) {
				child = current->right;
				*prev = child;
				free(current);
			} else if (current->left != NULL && current->right != NULL) {
				child = extract_smallest_node(&current->right);
				child->left = current->left;
				child->right = current->right;
				*prev = child;
				free(current);
			}
			flag = 1;
		} else {
			if (strcmp(current->data.name, name) < 0) {
				prev = &current->right;
				current = current->right;
			} else {
				prev = &current->left;
				current = current->left;
			}
		}
	}
}

