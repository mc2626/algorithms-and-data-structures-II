/*
 -------------------------------------
 File:    dllist.c
 Project: cp264_a5
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-02-14
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "dllist.h"

NODE* new_node(char data) {

	NODE *nn = (NODE*) malloc(sizeof(NODE));

	nn->data = data;
	nn->next = NULL;
	nn->prev = NULL;

	return nn;
}

void clean(DLLIST *dllistp) {

	NODE *temp, *p = dllistp->start;

	while (p != NULL) {
		temp = p;
		p = p->next;
		free(temp);
	}
	dllistp->start = NULL;
	dllistp->length = 0;
}

void insert_start(DLLIST *dllistp, NODE *np) {

	if (dllistp->start == NULL) {
		np->prev = NULL;
		np->next = NULL;
		dllistp->start = np;
		dllistp->end = np;
	} else {
		np->prev = NULL;
		np->next = dllistp->start;
		dllistp->start->prev = np;
		dllistp->start = np;
	}
	dllistp->length++;
}

void insert_end(DLLIST *dllistp, NODE *np) {

	if (dllistp->start == NULL) {
		np->prev = NULL;
		np->next = NULL;
		dllistp->start = np;
		dllistp->end = np;
	} else {
		np->next = NULL;
		np->prev = dllistp->end;
		dllistp->end->next = np;
		dllistp->end = np;
	}
	dllistp->length++;
}

void delete_start(DLLIST *dllistp) {

	if (dllistp->start != NULL) {
		if (dllistp->length == 1) {
			dllistp->start = NULL;
			dllistp->end = NULL;
		} else {
			NODE *temp = dllistp->start->next;
			dllistp->start->prev = dllistp->start;
			dllistp->start = temp;
			dllistp->start->prev = NULL;
		}
		dllistp->length--;
	}
}

void delete_end(DLLIST *dllistp) {

	if (dllistp->start != NULL) {
		if (dllistp->length == 1) {
			dllistp->start = NULL;
			dllistp->end = NULL;
		} else {
			NODE *temp = dllistp->end->prev;
			dllistp->end->prev = dllistp->end;
			dllistp->end = temp;
			dllistp->end->next = NULL;
		}
		dllistp->length--;
	}
}
