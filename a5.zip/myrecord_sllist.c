/*
 -------------------------------------
 File:    myrecord_sllist.c
 Project: cp264_a5
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-02-14
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "myrecord_sllist.h"

NODE* search(SLLIST *sllistp, char *name) {

	NODE *curr = sllistp->start;

	while (curr != NULL) {
		if (strcmp(curr->data.name, name) == 0) {
			return curr;
		}
		curr = curr->next;
	}

	return NULL;
}

void insert(SLLIST *sllistp, char *name, float score) {

	NODE *np = (NODE*) malloc(sizeof(NODE));
	strcpy(np->data.name, name);
	np->data.score = score;
	np->next = NULL;

	NODE *prev = NULL, *p = sllistp->start;
	while (p != NULL) {
		if (strcmp(p->data.name, name) >= 0) {
			break;
		}
		prev = p;
		p = p->next;

	}
	if (prev == NULL) {
		sllistp->start = np;
		np->next = p;
	} else {
		prev->next = np;
		np->next = p;
	}
	sllistp->length += 1;
}

int delete(SLLIST *sllistp, char *name) {

	NODE *prev = NULL, *p = sllistp->start;
	int result = 0;
	while (p != NULL) {
		if (strcmp(p->data.name, name) == 0) {
			result = 1;
			break;
		}
		prev = p;
		p = p->next;
	}
	if (prev == NULL) {
		sllistp->start = p->next;
	} else {
		prev->next = p->next;
	}
	free(p);

	return result;

}

void clean(SLLIST *sllistp) {

	NODE *temp, *p = sllistp->start;

	while (p != NULL) {
		temp = p;
		p = p->next;
		free(temp);
	}
	sllistp->start = NULL;
	sllistp->length = 0;
}

