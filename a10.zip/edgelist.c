/*
 -------------------------------------
 File:    edgelist.c
 Project: cvet1400_a10
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-04-05
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "edgelist.h"

EDGELIST* new_edgelist() {

	EDGELIST *p = malloc(sizeof(EDGELIST));
	p->start = NULL;
	p->end = NULL;
	p->size = 0;
	return p;
}

void add_edge_end(EDGELIST *g, int from, int to, int weight) {

	EDGE *new_edge = malloc(sizeof(EDGE));

	new_edge->from = from;
	new_edge->to = to;
	new_edge->weight = weight;
	new_edge->next = NULL;

	if (g->end == NULL) {
		g->start = new_edge;
	} else {
		g->end->next = new_edge;
	}

	g->end = new_edge;
	g->size++;
}

void add_edge_start(EDGELIST *g, int from, int to, int weight) {

	EDGE *new_edge = malloc(sizeof(EDGE));

	new_edge->from = from;
	new_edge->to = to;
	new_edge->weight = weight;
	new_edge->next = NULL;

	if (g->start == NULL) {
		g->end = new_edge;
	} else {
		new_edge->next = g->start;
	}

	g->start = new_edge;
	g->size++;
}

int weight_edgelist(EDGELIST *g) {

	EDGE *curr = (EDGE*) malloc(sizeof(EDGE));

	curr = g->start;
	int weight = 0;
	while (curr != NULL) {
		weight += curr->weight;
		curr = curr->next;
	}

	return weight;
}

void clean_edgelist(EDGELIST **gp) {

	EDGELIST *g = *gp;
	EDGE *temp, *p = g->start;
	while (p) {
		temp = p;
		p = p->next;
		free(temp);
	}
	free(g);
	*gp = NULL;
}

void display_edgelist(EDGELIST *g) {
	if (g == NULL)
		return;
	printf("size:%d\n", g->size);
	printf("(from to weight):");
	EDGE *p = g->start;
	while (p) {
		printf("(%d %d %d) ", p->from, p->to, p->weight);
		p = p->next;
	}
}

