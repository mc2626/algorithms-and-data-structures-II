/*
 -------------------------------------
 File:    graph.c
 Project: cvet1400_a10
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-04-06
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "queue_stack.h"
#include "graph.h"

GRAPH* new_graph(int order) {

	GRAPH *g = (GRAPH*) malloc(sizeof(GRAPH));
	g->order = order;
	g->size = 0; //initially no edges

	g->nodes = malloc(order * sizeof(GNODE*));
	for (int i = 0; i < order; i++) {
		g->nodes[i] = malloc(sizeof(GNODE)); //create a GNODE object
		g->nodes[i]->nid = i; //set node id to be i
		g->nodes[i]->neighbor = NULL; //initialize neighbor linked list
	}

	return g;
}

void add_edge(GRAPH *g, int from, int to, int weight) {

	GNODE *f_node = g->nodes[from]; // from node
	ADJNODE *anp = f_node->neighbor;
	ADJNODE *prev;
	int adjj = 0;
	int has_neighbors = 0;
	if (anp)
		has_neighbors = 1;
	//check if adjacent
	while (anp && adjj == 0) {
		if (anp->nid == to) { // if neighbor exists
			adjj = 1;
			anp->weight = weight;
		} else {
			prev = anp;
			anp = anp->next;
		}

	}
	//if nodes are not adjacent then add edge
	if (adjj == 0) {
		ADJNODE *adjj_new = (ADJNODE*) malloc(sizeof(ADJNODE));
		adjj_new->nid = to;
		adjj_new->weight = weight;
		adjj_new->next = NULL;
		if (has_neighbors == 1) {
			prev->next = adjj_new;
		} else {
			f_node->neighbor = adjj_new;
		}
		g->size++;
	}
}

int get_weight(GRAPH *g, int from, int to) {

	ADJNODE *a = g->nodes[from]->neighbor;
	int res = INFINITY;
	int flag = 0;
	while (a && !flag) {
		if (a->nid == to) {
			res = a->weight;
			flag = 1;
		}
		a = a->next;
	}
	return res;
}

void clean_graph(GRAPH **gp) {

	int i;
	GRAPH *g = *gp;
	ADJNODE *temp, *ptr;
	for (i = 0; i < g->order; i++) {
		ptr = g->nodes[i]->neighbor;
		while (ptr != NULL) {
			temp = ptr;
			ptr = ptr->next;
			free(temp);
		}
		free(g->nodes[i]);
	}
	free(g->nodes);
	free(g);
	*gp = NULL;
}

void display_bforder(GRAPH *g, int start) {
// your implementation
// use format "%d " to print node id

	if (g == NULL)
		return;
	//get order and set the visited array
	int n = g->order;
	int visited[n];
	int i;
	for (i = 0; i < n; i++) {
		visited[i] = 0;
	}
	//bfs
	QUEUE queue = { 0 };
	GNODE *gnp = NULL;
	ADJNODE *anp = NULL;
	enqueue(&queue, g->nodes[start]);
	visited[start] = 1;
	while (queue.front) {
		gnp = (GNODE*) dequeue(&queue);
		printf("%d ", gnp->nid);
		anp = gnp->neighbor;
		while (anp) {
			i = anp->nid;
			if (visited[i] == 0) {
				enqueue(&queue, g->nodes[i]);
				visited[i] = 1;
			}
			anp = anp->next;
		}
	}
	clean_queue(&queue);
}

void display_dforder(GRAPH *g, int start) {
// your implementation
// use format "%d " to print node id

	int n = g->order;
	int visited[n];
	int i;
	for (i = 0; i < n; i++) {
		visited[i] = 0;
	}

	//dfs
	STACK stack = { 0 };
	GNODE *gnp = NULL;
	ADJNODE *anp = NULL;
	push(&stack, g->nodes[start]);
	visited[start] = 1;
	while (stack.top) {
		gnp = pop(&stack);
		printf("%d ", gnp->nid);
		anp = gnp->neighbor;
		while (anp) {
			i = anp->nid;
			if (visited[i] == 0) {
				push(&stack, g->nodes[i]);
				visited[i] = 1;
			}
			anp = anp->next;
		}
	}
	clean_stack(&stack);
}

void display_graph(GRAPH *g) {
	if (g == NULL)
		return;
	printf("order:%d\n", g->order);
	printf("size:%d\n", g->size);
	printf("from:(to weight)");
	int i;
	ADJNODE *ptr;
	for (i = 0; i < g->order; i++) {
		printf("\n%d:", g->nodes[i]->nid);
		ptr = g->nodes[i]->neighbor;
		while (ptr != NULL) {
			printf("(%d %d) ", ptr->nid, ptr->weight);
			ptr = ptr->next;
		}
	}
}
