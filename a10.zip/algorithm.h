/*
 -------------------------------------
 File:    algorithm.h
 Project: cvet1400_a10
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-04-06
 -------------------------------------
 */
#ifndef ALGORITHM_H
#define ALGORITHM_H

#include "edgelist.h"
#include "graph.h"

EDGELIST* mst_prim(GRAPH *g, int start);
EDGELIST* spt_dijkstra(GRAPH *g, int start);
EDGELIST* sp_dijkstra(GRAPH *g, int start, int end);

#endif
