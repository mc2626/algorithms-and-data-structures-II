/*
 -------------------------------------
 File:    algorithm.c
 Project: cvet1400_a10
 file description
 -------------------------------------
 Author:  Mila Cvetanovska
 ID:      210311400
 Email:   cvet1400@mylaurier.ca
 Version  2023-04-06
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "heap.h"
#include "algorithm.h"

EDGELIST* mst_prim(GRAPH *g, int start) {

	//if no graph return null
	if (g == NULL)
		return NULL;
	int i, heapindex, u, n = g->order, T[n], parent[n];

	//label all nodes inside the T array
	for (i = 0; i < n; i++)
		T[i] = 0;
	for (i = 0; i < n; i++)
		parent[i] = -1;
	HEAPNODE hn;
	HEAP *h = new_heap(4);
	T[start] = 1;

	//get neighbors of root
	ADJNODE *temp = g->nodes[start]->neighbor;
	while (temp) {
		hn.key = temp->weight;
		hn.data = temp->nid;
		insert(h, hn);
		parent[temp->nid] = start;
		temp = temp->next;
	}
	//initialize an edgelist to hold the mst
	EDGELIST *mst = new_edgelist();
	//add all edges to the mst
	//heap will store at most 4 values (in this example) since there will never be duplicate nodes added
	//any time a duplicate node is added instead of actually inserting it you just change_key
	while (h->size > 0) {
		//take the minimum edge from Graph connected to nodes already in mst
		hn = extract_min(h);
		i = hn.data;
		T[i] = 1;
		//add this edge to the mst
		add_edge_end(mst, parent[i], i, hn.key);
		//add all neighbors of this new node to the heap
		temp = g->nodes[i]->neighbor;
		while (temp) {
			//find the node in the heap
			heapindex = find_data_index(h, temp->nid);
			//if the node is in the heap then relax it
			if (heapindex >= 0) {
				if (T[temp->nid] == 0 && temp->weight < h->hna[heapindex].key) {
					change_key(h, heapindex, temp->weight);
					parent[temp->nid] = i;
				}
			} else {
				if (T[temp->nid] == 0) {
					hn.key = temp->weight;
					hn.data = temp->nid;
					insert(h, hn);
					parent[temp->nid] = i;
				}
			}
			temp = temp->next;
		}
	}

	return mst;
}

EDGELIST* spt_dijkstra(GRAPH *g, int start) {

	//if there is no graph then return null
	if (!g)
		return NULL;
	//create a new edgelist to represent the tree
	EDGELIST *spt = new_edgelist();
	//n will be the number of nodes (the order of the graph)
	int i, u, n = g->order;
	//parent array will be for backtracking
	int T[n], parent[n], label[n];
	HEAPNODE hn;

	//make an array T to hold the nodes, give them values from 0 to n (their start)
	//make an array label to represent the weight of node i from root node
	for (i = 0; i < n; i++) {
		T[i] = 0;
		label[i] = 9999;
	}
	//create a new heap that can initially hold 4 objects
	HEAP *h = new_heap(4);

	//assign the root node the proper start and weight
	label[start] = 0;
	T[start] = 1;
	u = start;

	//insert all of the root nodes' neighbors into a heap
	while ((g->order - 1) - spt->size != 0) {
		ADJNODE *v = g->nodes[u]->neighbor;
		while (v != NULL) {
			if (label[u] + v->weight < label[v->nid]) {
				label[v->nid] = label[u] + v->weight;
				parent[v->nid] = u;
				hn.key = v->weight + label[u];
				hn.data = v->nid;
				insert(h, hn);
			}
			v = v->next;
		}

		if (h->size != 0) {
			hn = extract_min(h);
			if (label[hn.data] != 9999) {
				u = hn.data;
				T[u] = 1;
				label[u] = hn.key;
				add_edge_end(spt, parent[u], u, label[u] - label[parent[u]]);
			}
		}
	}

	return spt;
}

EDGELIST* sp_dijkstra(GRAPH *g, int start, int end) {

	//if there is no graph then just return null
	if (!g)
		return NULL;
	EDGELIST *spt = new_edgelist();
	int i, heapindex, u, n = g->order;
	int T[n], parent[n], label[n];
	HEAPNODE hn;
	//set T array up with all nodes in graph and their corresponding ends
	//set label array up to initially give all nodes a distance of infinity away from the root node
	for (i = 0; i < n; i++) {
		T[i] = 0;
		label[i] = 9999;
	}
	//instantiate a heap to use as a priority queue
	HEAP *h = new_heap(4);
	label[start] = 0;
	T[start] = 1;

	u = start;

	//insert all of the root nodes' neighbors into the heap
	while ((g->order - 1) - spt->size != 0) {
		ADJNODE *v = g->nodes[u]->neighbor;
		while (v) {
			if (label[u] + v->weight < label[v->nid]) {
				label[v->nid] = label[u] + v->weight;
				parent[v->nid] = u;
				hn.key = v->weight + label[u];
				hn.data = v->nid;
				insert(h, hn);
			}
			v = v->next;
		}

		if (h->size != 0) {
			hn = extract_min(h);
			if (label[hn.data] != 9999) {
				u = hn.data;
				T[u] = 1;
				label[u] = hn.key;
				add_edge_end(spt, parent[u], u, label[u] - label[parent[u]]);
			}
		}
	}
	//now with shortest path tree created, back track through it to find the shortest path from end to start
	EDGELIST *sp = new_edgelist();
	i = end;
	while (1) {
		if (i == start)
			break;
		add_edge_start(sp, parent[i], i, label[i] - label[parent[i]]);
		i = parent[i];
	}
	return sp;
}
